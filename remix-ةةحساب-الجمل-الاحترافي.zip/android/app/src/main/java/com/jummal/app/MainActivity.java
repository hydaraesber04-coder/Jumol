package com.jummal.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
