import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.jummal.app',
  appName: 'حساب الجمل',
  webDir: 'dist'
};

export default config;
