import React, { Component, ReactNode, StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';

interface ErrorBoundaryProps {
  children: ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
  error: Error | null;
}

class ErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error) {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.error('ErrorBoundary caught error:', error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div style={{
          minHeight: '100vh',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          padding: '24px',
          backgroundColor: '#f8fafc',
          color: '#1e293b',
          fontFamily: 'system-ui, -apple-system, sans-serif',
          textAlign: 'center',
          direction: 'rtl'
        }}>
          <div style={{
            background: 'white',
            padding: '32px',
            borderRadius: '24px',
            boxShadow: '0 10px 25px rgba(0,0,0,0.08)',
            maxWidth: '400px',
            width: '100%',
            border: '1px solid #fee2e2'
          }}>
            <div style={{ fontSize: '40px', marginBottom: '16px' }}>⚠️</div>
            <h2 style={{ fontSize: '20px', fontWeight: 'bold', color: '#991b1b', marginBottom: '8px' }}>
              تنبيه في تشغيل التطبيق
            </h2>
            <p style={{ fontSize: '13px', color: '#64748b', marginBottom: '20px', wordBreak: 'break-all' }}>
              {this.state.error?.message || 'حدث خطأ أثناء عرض واجهة التطبيق'}
            </p>
            <button
              onClick={() => window.location.reload()}
              style={{
                width: '100%',
                padding: '12px 24px',
                backgroundColor: '#4f46e5',
                color: 'white',
                border: 'none',
                borderRadius: '12px',
                fontWeight: 'bold',
                cursor: 'pointer'
              }}
            >
              إعادة التحميل
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

// إزالة شاشة البداية فوراً
function dismissSplash() {
  const loader = document.getElementById('splash-loader');
  if (loader) {
    loader.style.opacity = '0';
    loader.style.pointerEvents = 'none';
    setTimeout(() => {
      try { loader.remove(); } catch (_) {}
    }, 250);
  }
}

try {
  const container = document.getElementById('root');
  if (container) {
    const root = createRoot(container);
    root.render(
      <StrictMode>
        <ErrorBoundary>
          <App />
        </ErrorBoundary>
      </StrictMode>,
    );
    dismissSplash();
  }
} catch (err) {
  console.error('Mount error:', err);
  const loader = document.getElementById('splash-loader');
  if (loader) {
    loader.innerHTML = `
      <div style="padding: 24px; text-align: center; color: white; font-family: sans-serif;">
        <h3 style="margin-bottom: 8px;">تعذر تشغيل التطبيق</h3>
        <p style="font-size: 13px; opacity: 0.9; margin-bottom: 16px;">${String(err)}</p>
        <button onclick="location.reload()" style="padding: 8px 20px; background: white; color: #4f46e5; border: none; border-radius: 8px; font-weight: bold;">إعادة المحاولة</button>
      </div>
    `;
  }
}

if ('serviceWorker' in navigator && window.location.protocol.startsWith('http') && !window.location.hostname.includes('localhost')) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('./sw.js').catch(() => {});
  });
}

