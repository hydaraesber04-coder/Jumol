import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// إزالة شاشة البداية فوراً
function dismissSplash() {
  const loader = document.getElementById('splash-loader');
  if (loader) {
    loader.style.opacity = '0';
    loader.style.pointerEvents = 'none';
    setTimeout(() => {
      try { loader.remove(); } catch (_) {}
    }, 250);
  }
}

try {
  const container = document.getElementById('root');
  if (container) {
    const root = createRoot(container);
    root.render(
      <StrictMode>
        <App />
      </StrictMode>,
    );
    // إخفاء شاشة البداية بمجرد إعطاء أمر الـ render
    dismissSplash();
  }
} catch (err) {
  console.error('Mount error:', err);
  const loader = document.getElementById('splash-loader');
  if (loader) {
    loader.innerHTML = `
      <div style="padding: 24px; text-align: center; color: white; font-family: sans-serif;">
        <h3 style="margin-bottom: 8px;">تعذر تشغيل التطبيق</h3>
        <p style="font-size: 13px; opacity: 0.9; margin-bottom: 16px;">${String(err)}</p>
        <button onclick="location.reload()" style="padding: 8px 20px; background: white; color: #4f46e5; border: none; border-radius: 8px; font-weight: bold;">إعادة المحاولة</button>
      </div>
    `;
  }
}

if ('serviceWorker' in navigator && window.location.protocol.startsWith('http') && !window.location.hostname.includes('localhost')) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('./sw.js').catch(() => {});
  });
}

