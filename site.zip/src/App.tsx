/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { 
  Calculator, 
  Search, 
  Star, 
  Trash2, 
  Plus, 
  X, 
  RefreshCw, 
  MessageSquare,
  Send,
  Loader2,
  Book,
  ArrowUp,
  ArrowDown,
  ArrowUpDown,
  BookPlus
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { ARABIC_DICTIONARY } from '../dictionary';

// --- Constants & Data ---

const BIG_VALUES: Record<string, number> = {
  'ا': 1, 'أ': 1, 'إ': 1, 'آ': 1, 'ب': 2, 'ج': 3, 'د': 4, 'ه': 5, 'و': 6, 'ز': 7, 'ح': 8, 'ط': 9, 'ي': 10,
  'ك': 20, 'ل': 30, 'م': 40, 'ن': 50, 'س': 60, 'ع': 70, 'ف': 80, 'ص': 90, 'ق': 100, 'ر': 200, 'ش': 300,
  'ت': 400, 'ث': 500, 'خ': 600, 'ذ': 700, 'ض': 800, 'ظ': 900, 'غ': 1000
};

const SMALL_BASIS_VALUES: Record<string, number> = {
  'أ': 1, 'ا': 1, 'إ': 1, 'آ': 1, 'ب': 2, 'ن': 2, 'ج': 3, 'ذ': 4, 'غ': 4, 'م': 4, 'ق': 4, 'د': 4, 'ت': 4,
  'ه': 5, 'و': 6, 'ص': 6, 'ل': 6, 'ز': 7, 'ث': 8, 'ح': 8, 'ك': 8, 'ض': 8, 'ف': 8, 'ر': 8, 'ط': 9,
  'ع': 10, 'ي': 10, 'س': 12, 'ش': 12, 'خ': 12, 'ظ': 12
};

const DROP_9_VALUES: Record<string, number> = {
  'ا': 1, 'أ': 1, 'إ': 1, 'آ': 1, 'ي': 1, 'ق': 1, 'غ': 1, 'ب': 2, 'ك': 2, 'ر': 2, 'ج': 3, 'ل': 3, 'ش': 3,
  'د': 4, 'م': 4, 'ت': 4, 'ه': 5, 'ن': 5, 'ث': 5, 'و': 6, 'س': 6, 'خ': 6, 'ز': 7, 'ع': 7, 'ذ': 7,
  'ح': 8, 'ف': 8, 'ض': 8, 'ط': 9, 'ص': 9, 'ظ': 9
};

// --- Utilities ---

function preprocess(text: string) {
  let t = text.trim();
  
  t = t.replace(/ة/g, 'ه').replace(/ى/g, 'ا');
  t = t.replace(/ء(?=\s|$)/g, '');
  return t.replace(/[^\u0621-\u064A\s]/g, '');
}

function calculateValues(text: string) {
  const clean = preprocess(text);
  let big = 0, smallBasis = 0, drop9 = 0;
  const breakdown: { char: string; big: number; small: number }[] = [];

  for (const char of clean) {
    if (char === ' ') continue;
    const b = BIG_VALUES[char] || 0;
    const s = SMALL_BASIS_VALUES[char] || 0;
    const d = DROP_9_VALUES[char] || 0;
    big += b;
    smallBasis += s;
    drop9 += d;
    breakdown.push({ char, big: b, small: s });
  }

  return { big, smallBasis, drop9, breakdown, clean };
}

// --- Components ---

export default function App() {
  const [activeTab, setActiveTab] = useState<'calc' | 'search' | 'fav' | 'dict'>('calc');
  const [inputText, setInputText] = useState('');
  const [favorites, setFavorites] = useState<{ word: string; big: number; small: number; drop9: number }[]>([]);
  const [personalDictionary, setPersonalDictionary] = useState<string[]>([]);
  const [sortConfig, setSortConfig] = useState<{ key: 'big' | 'small' | 'drop9' | null; direction: 'asc' | 'desc' | null }>({ key: null, direction: null });
  
  // Reverse Search State
  const [revMethod, setRevMethod] = useState<'big' | 'smallBasis' | 'drop9'>('big');
  const [revTarget, setRevTarget] = useState(26);
  const [revChars, setRevChars] = useState(3);
  const [revResults, setRevResults] = useState<{ chars: string; isKnown: boolean }[]>([]);
  const [isSearching, setIsSearching] = useState(false);

  // Generator State
  const [showGenModal, setShowGenModal] = useState(false);
  const [genMethod, setGenMethod] = useState<'big' | 'smallBasis' | 'drop9'>('big');
  const [genTarget, setGenTarget] = useState(0);
  const [genResults, setGenResults] = useState<{ chars: string; isKnown: boolean }[]>([]);

  const { big, smallBasis, drop9, breakdown, clean } = useMemo(() => calculateValues(inputText), [inputText]);

  const combinedDictionary = useMemo(() => {
    return Array.from(new Set([...ARABIC_DICTIONARY, ...personalDictionary]));
  }, [personalDictionary]);

  const peerWords = useMemo(() => {
    if (!clean.trim()) return [];
    return combinedDictionary.filter(w => {
      if (w === inputText.trim()) return false;
      const cw = preprocess(w);
      let sumB = 0, sumS = 0;
      for (const c of cw) {
        sumB += (BIG_VALUES[c] || 0);
        sumS += (SMALL_BASIS_VALUES[c] || 0);
      }
      // Peer words must match BOTH Big AND Small Basis values
      return sumB === big && sumS === smallBasis;
    });
  }, [clean, big, smallBasis, inputText]);

  // Load local storage data safely
  useEffect(() => {
    try {
      const savedFavs = localStorage.getItem('abjad_favorites');
      if (savedFavs) setFavorites(JSON.parse(savedFavs));
      
      const savedDict = localStorage.getItem('abjad_personal_dict');
      if (savedDict) setPersonalDictionary(JSON.parse(savedDict));
    } catch (e) {
      console.warn('localStorage access failed:', e);
    }
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem('abjad_favorites', JSON.stringify(favorites));
    } catch (e) {
      console.warn('localStorage set failed:', e);
    }
  }, [favorites]);

  useEffect(() => {
    try {
      localStorage.setItem('abjad_personal_dict', JSON.stringify(personalDictionary));
    } catch (e) {
      console.warn('localStorage set failed:', e);
    }
  }, [personalDictionary]);

  const sortedFavorites = useMemo(() => {
    let sortableItems = [...favorites];
    if (sortConfig.key !== null && sortConfig.direction !== null) {
      sortableItems.sort((a, b) => {
        if (a[sortConfig.key!] < b[sortConfig.key!]) {
          return sortConfig.direction === 'asc' ? -1 : 1;
        }
        if (a[sortConfig.key!] > b[sortConfig.key!]) {
          return sortConfig.direction === 'asc' ? 1 : -1;
        }
        return 0;
      });
    }
    return sortableItems;
  }, [favorites, sortConfig]);

  const requestSort = (key: 'big' | 'small' | 'drop9') => {
    let direction: 'asc' | 'desc' | null = 'asc';
    if (sortConfig.key === key && sortConfig.direction === 'asc') direction = 'desc';
    else if (sortConfig.key === key && sortConfig.direction === 'desc') { direction = null; key = null as any; }
    setSortConfig({ key, direction });
  };

  const getSortIcon = (columnName: 'big' | 'small' | 'drop9') => {
    if (sortConfig.key !== columnName) return <ArrowUpDown size={14} className="opacity-30 inline-block mr-1" />;
    return sortConfig.direction === 'asc' 
      ? <ArrowUp size={14} className="inline-block mr-1 text-indigo-600" />
      : <ArrowDown size={14} className="inline-block mr-1 text-indigo-600" />;
  };

  const addToFavorites = () => {
    if (!inputText.trim()) return;
    if (favorites.some(f => f.word === inputText.trim())) return;
    setFavorites([...favorites, { word: inputText.trim(), big, small: smallBasis, drop9 }]);
  };

  const addToDictionary = () => {
    const word = inputText.trim();
    if (!word) return;
    if (combinedDictionary.includes(word)) return;
    setPersonalDictionary([...personalDictionary, word]);
  };

  const removeFavorite = (wordToRemove: string) => {
    setFavorites(favorites.filter(f => f.word !== wordToRemove));
  };

  const startReverseSearch = () => {
    setIsSearching(true);
    setTimeout(() => {
      const results = generateMatches(revTarget, revChars, revMethod);
      setRevResults(results);
      setIsSearching(false);
    }, 600);
  };

  const generateMatches = (target: number, count: number, method: string) => {
    const table = method === 'big' ? BIG_VALUES : (method === 'smallBasis' ? SMALL_BASIS_VALUES : DROP_9_VALUES);
    let matches: { chars: string; isKnown: boolean }[] = [];

    // Dictionary matches ONLY
    combinedDictionary.forEach(w => {
      const cw = preprocess(w);
      // If count is 0, we matching only the value. 
      // If count is specified (from Search tab or Modal), we match character count too.
      const matchesCount = count === 0 || cw.length === count;
      
      if (matchesCount) {
        let s = 0;
        for (const c of cw) s += (table[c] || 0);
        if (s === target) {
          // Avoid duplicates
          if (!matches.some(m => m.chars === w)) {
            matches.push({ chars: w, isKnown: true });
          }
        }
      }
    });

    return matches;
  };

  const openGenerator = (method: 'big' | 'smallBasis' | 'drop9', target: number) => {
    if (target === 0) return;
    setGenMethod(method);
    setGenTarget(target);
    setGenResults([]);
    setShowGenModal(true);
  };

  const runGenerator = (count: number) => {
    const res = generateMatches(genTarget, count, genMethod);
    setGenResults(res);
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-['Tajawal'] dir-rtl" dir="rtl">
      <div className="max-w-3xl mx-auto px-4 py-8">
        
        {/* Header */}
        <header className="text-center mb-10">
          <motion.h1 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl font-black text-indigo-900 mb-2"
          >
            حساب الجُمَّل الاحترافي
          </motion.h1>
          <p className="text-slate-500 font-medium">استكشف أسرار الحروف والأرقام</p>
        </header>

        {/* Navigation Tabs */}
        <div className="flex bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden mb-8">
          {[
            { id: 'calc', label: 'الحاسبة', icon: Calculator },
            { id: 'search', label: 'البحث العكسي', icon: Search },
            { id: 'fav', label: 'المفضلة', icon: Star },
            { id: 'dict', label: 'قاموسي', icon: Book },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex-1 py-4 flex flex-col items-center gap-1 transition-all relative ${
                activeTab === tab.id ? 'text-indigo-600 bg-indigo-50/50' : 'text-slate-400 hover:text-slate-600'
              }`}
            >
              <tab.icon size={20} strokeWidth={activeTab === tab.id ? 2.5 : 2} />
              <span className="text-sm font-bold">{tab.label}</span>
              {activeTab === tab.id && (
                <motion.div 
                  layoutId="activeTab"
                  className="absolute bottom-0 left-0 right-0 h-1 bg-indigo-600"
                />
              )}
              {tab.id === 'fav' && favorites.length > 0 && (
                <span className="absolute top-2 right-1/4 bg-red-500 text-white text-[10px] px-1.5 py-0.5 rounded-full font-bold">
                  {favorites.length}
                </span>
              )}
            </button>
          ))}
        </div>

        {/* Tab Content */}
        <main>
          <AnimatePresence mode="wait">
            
            {/* Calculator Tab */}
            {activeTab === 'calc' && (
              <motion.div
                key="calc"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <div className="bg-white rounded-3xl shadow-xl shadow-indigo-100/50 p-8 border border-indigo-50">
                  <textarea
                    value={inputText}
                    onChange={(e) => setInputText(e.target.value)}
                    placeholder="اكتب هنا..."
                    className="w-full bg-slate-50 border-none focus:ring-0 text-4xl text-center font-black text-slate-800 placeholder:text-slate-200 rounded-2xl p-6 min-h-[120px] resize-none"
                    dir="rtl"
                  />
                  <div className="flex flex-wrap justify-center mt-6 gap-4">
                    <button 
                      onClick={addToFavorites}
                      className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-3 rounded-full font-bold transition-all shadow-lg shadow-indigo-200"
                    >
                      <Star size={18} />
                      إضافة للمفضلة
                    </button>
                    <button 
                      onClick={addToDictionary}
                      disabled={combinedDictionary.includes(inputText.trim())}
                      className="flex items-center gap-2 bg-sky-500 hover:bg-sky-600 text-white px-6 py-3 rounded-full font-bold transition-all shadow-lg shadow-sky-200 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      <BookPlus size={18} />
                      {combinedDictionary.includes(inputText.trim()) && inputText.trim() ? 'موجود فى القاموس' : 'إضافة للقاموس'}
                    </button>
                  </div>
                </div>

                {/* Results Grid */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <ResultCard 
                    title="الجمل الكبير" 
                    value={big} 
                    onGen={() => openGenerator('big', big)}
                    color="sky"
                    featured
                  />
                  <ResultCard 
                    title="الجمل الصغير الأساسي" 
                    value={smallBasis} 
                    onGen={() => openGenerator('smallBasis', smallBasis)}
                    color="indigo"
                    featured
                  />
                  <ResultCard 
                    title="إسقاط 9" 
                    value={drop9} 
                    onGen={() => openGenerator('drop9', drop9)}
                    color="emerald"
                    featured
                  />
                </div>

                {/* Peer Words */}
                {peerWords.length > 0 && (
                  <motion.div 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="bg-indigo-50/50 border border-indigo-100 p-6 rounded-3xl"
                  >
                    <h3 className="text-xs font-bold text-indigo-400 uppercase tracking-wider mb-3">نظير الكلمة (توافق القيمة):</h3>
                    <div className="flex flex-wrap gap-2">
                      {peerWords.map((word, i) => (
                        <span key={i} className="bg-white px-4 py-2 rounded-xl text-sm font-bold text-indigo-700 border border-indigo-100 shadow-sm">
                          {word}
                        </span>
                      ))}
                    </div>
                  </motion.div>
                )}

                {/* Breakdown */}
                {breakdown.length > 0 && (
                  <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100">
                    <div className="flex flex-wrap justify-center gap-3">
                      {breakdown.map((item, i) => (
                        <div key={i} className="bg-slate-50 p-3 rounded-2xl text-center min-w-[64px] border border-slate-100 hover:border-indigo-200 transition-colors">
                          <div className="text-[10px] font-bold text-slate-400 mb-1">{item.big} | {item.small}</div>
                          <div className="text-2xl font-black text-slate-800">{item.char}</div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </motion.div>
            )}

            {/* Reverse Search Tab */}
            {activeTab === 'search' && (
              <motion.div
                key="search"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="bg-white rounded-3xl shadow-xl p-8 border border-slate-100"
              >
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-400 block px-1">نوع الجمل</label>
                    <select 
                      value={revMethod}
                      onChange={(e) => setRevMethod(e.target.value as any)}
                      className="w-full p-4 bg-slate-50 rounded-2xl outline-none border border-slate-100 font-bold text-indigo-900 appearance-none"
                    >
                      <option value="big">الجمل الكبير</option>
                      <option value="smallBasis">الجمل الصغير الأساسي</option>
                      <option value="drop9">إسقاط 9</option>
                    </select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-400 block px-1">الرقم المستهدف</label>
                    <input 
                      type="number" 
                      value={revTarget}
                      onChange={(e) => setRevTarget(parseInt(e.target.value) || 0)}
                      className="w-full p-4 bg-slate-50 rounded-2xl outline-none border border-slate-100 font-bold text-center"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-400 block px-1">عدد الحروف</label>
                    <input 
                      type="number" 
                      value={revChars}
                      onChange={(e) => setRevChars(parseInt(e.target.value) || 0)}
                      className="w-full p-4 bg-slate-50 rounded-2xl outline-none border border-slate-100 font-bold text-center"
                    />
                  </div>
                </div>

                <button 
                  onClick={startReverseSearch}
                  disabled={isSearching}
                  className="w-full py-5 bg-indigo-600 text-white rounded-2xl font-black shadow-lg shadow-indigo-100 hover:bg-indigo-700 transition-all flex items-center justify-center gap-3"
                >
                  {isSearching ? <RefreshCw className="animate-spin" /> : <Search size={20} />}
                  بدء البحث والاستنباط العكسي
                </button>

                <div className="mt-10 space-y-3">
                  {revResults.map((res, i) => (
                    <div 
                      key={i} 
                      className={`p-5 border rounded-2xl flex justify-between items-center transition-all ${
                        res.isKnown 
                          ? 'bg-indigo-50 border-indigo-200 shadow-sm' 
                          : 'bg-slate-50 border-slate-100 hover:border-indigo-200'
                      }`}
                    >
                      <div className="flex items-center gap-4">
                        <span className={`text-3xl font-black tracking-[0.2em] ${res.isKnown ? 'text-indigo-900' : 'text-slate-800'}`}>
                          {res.chars}
                        </span>
                        {res.isKnown && (
                          <span className="text-[10px] bg-indigo-600 text-white px-2.5 py-1 rounded-full font-black uppercase">كلمة معروفة</span>
                        )}
                      </div>
                      <span className="text-xs font-bold text-slate-300">مجموع: {revTarget}</span>
                    </div>
                  ))}
                  {!isSearching && revResults.length === 0 && (
                    <div className="text-center py-10 text-slate-300 italic">أدخل المعايير وابدأ البحث</div>
                  )}
                </div>
              </motion.div>
            )}

            {/* Favorites Tab */}
            {activeTab === 'fav' && (
              <motion.div
                key="fav"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="bg-white rounded-3xl shadow-xl overflow-hidden border border-slate-100"
              >
                <div className="overflow-x-auto">
                  <table className="w-full text-center">
                    <thead className="bg-slate-50 border-b border-slate-100">
                      <tr>
                        <th className="py-5 px-4 text-xs font-bold text-slate-400">الكلمة</th>
                        <th 
                          onClick={() => requestSort('big')}
                          className="py-5 px-4 text-xs font-bold text-slate-400 cursor-pointer hover:bg-slate-100 transition-colors select-none"
                        >
                          {getSortIcon('big')} كبير
                        </th>
                        <th 
                          onClick={() => requestSort('small')}
                          className="py-5 px-4 text-xs font-bold text-slate-400 cursor-pointer hover:bg-slate-100 transition-colors select-none"
                        >
                          {getSortIcon('small')} صغير أساسي
                        </th>
                        <th 
                          onClick={() => requestSort('drop9')}
                          className="py-5 px-4 text-xs font-bold text-slate-400 cursor-pointer hover:bg-slate-100 transition-colors select-none"
                        >
                          {getSortIcon('drop9')} إسقاط 9
                        </th>
                        <th className="py-5 px-4 text-xs font-bold text-slate-400">إجراء</th>
                      </tr>
                    </thead>
                    <tbody>
                      {sortedFavorites.map((f, index) => (
                        <tr key={index} className="border-b border-slate-50 hover:bg-indigo-50/30 transition-colors">
                          <td className="py-5 font-black text-slate-700 text-lg">{f.word}</td>
                          <td className="py-5 text-slate-500 font-medium">{f.big}</td>
                          <td className="py-5 text-indigo-600 font-black">{f.small}</td>
                          <td className="py-5 text-slate-500 font-medium">{f.drop9}</td>
                          <td className="py-5">
                            <button 
                              onClick={() => removeFavorite(f.word)}
                              className="text-red-300 hover:text-red-500 transition-colors p-2"
                            >
                              <Trash2 size={18} />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                {favorites.length === 0 && (
                  <div className="p-20 text-center text-slate-300 italic flex flex-col items-center gap-4">
                    <Star size={48} className="opacity-20" />
                    المفضلة فارغة حالياً
                  </div>
                )}
              </motion.div>
            )}

            {/* Dictionary Tab */}
            {activeTab === 'dict' && (
              <motion.div
                key="dict"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="bg-white rounded-3xl shadow-xl overflow-hidden border border-slate-100"
              >
                <div className="p-6 bg-slate-50 border-b border-slate-100 flex flex-col md:flex-row gap-4 justify-between items-center">
                  <div className="text-center md:text-right">
                    <h2 className="text-xl font-black text-indigo-900">القاموس الشخصي</h2>
                    <p className="text-xs text-slate-500 mt-1">الكلمات التي أضفتها ستظهر في حسابات التوافق والاستنباط العكسي</p>
                  </div>
                  <div className="bg-white text-indigo-600 font-black px-4 py-2 rounded-xl shadow-sm border border-slate-100">
                    {personalDictionary.length} كلمة
                  </div>
                </div>
                
                <div className="p-6 max-h-[400px] overflow-y-auto custom-scrollbar">
                  {personalDictionary.length > 0 ? (
                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                      {personalDictionary.map((word, index) => (
                        <div key={index} className="bg-white border border-slate-100 rounded-2xl p-4 flex justify-between items-center group hover:border-indigo-200 transition-colors shadow-sm cursor-default">
                          <span className="font-bold text-slate-700">{word}</span>
                          <button 
                            onClick={() => {
                              setPersonalDictionary(personalDictionary.filter(w => w !== word));
                            }}
                            className="text-slate-300 hover:text-red-500 md:opacity-0 md:group-hover:opacity-100 transition-all font-bold"
                            title="حذف من القاموس"
                          >
                            <Trash2 size={16} />
                          </button>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="py-20 text-center text-slate-300 flex flex-col items-center gap-4">
                      <Book className="opacity-20 w-16 h-16" />
                      <p className="italic font-medium">لم تضف أية كلمات للقاموس الشخصي بعد</p>
                    </div>
                  )}
                </div>
              </motion.div>
            )}

          </AnimatePresence>
        </main>
      </div>

      {/* Generator Modal */}
      <AnimatePresence>
        {showGenModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowGenModal(false)}
              className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="bg-white w-full max-w-sm rounded-[2.5rem] p-8 shadow-2xl relative z-10 border border-indigo-50"
            >
              <button 
                onClick={() => setShowGenModal(false)}
                className="absolute top-6 left-6 text-slate-300 hover:text-slate-500 transition-colors"
              >
                <X size={24} />
              </button>
              
              <div className="text-center mb-8">
                <h2 className="text-2xl font-black text-indigo-900 mb-1">توليد توافقات</h2>
                <p className="text-xs text-slate-400 font-bold">للقيمة: {genTarget}</p>
              </div>

              <div className="flex gap-2 mb-8 justify-center">
                {[2, 3, 4, 5].map(n => (
                  <button 
                    key={n}
                    onClick={() => runGenerator(n)}
                    className="w-12 h-12 bg-slate-50 hover:bg-indigo-600 hover:text-white rounded-2xl font-black transition-all border border-slate-100 flex items-center justify-center"
                  >
                    {n}
                  </button>
                ))}
              </div>

              <div className="max-h-64 overflow-y-auto space-y-2 pr-2 custom-scrollbar">
                {genResults.map((res, i) => (
                  <div 
                    key={i} 
                    className={`p-4 rounded-2xl text-center font-black tracking-[0.3em] border text-xl flex items-center justify-center gap-3 ${
                      res.isKnown 
                        ? 'bg-indigo-50 border-indigo-200 text-indigo-900' 
                        : 'bg-slate-50 border-slate-100 text-slate-700'
                    }`}
                  >
                    {res.chars}
                    {res.isKnown && (
                      <span className="text-[8px] bg-indigo-600 text-white px-1.5 py-0.5 rounded-full font-black uppercase tracking-normal">معروفة</span>
                    )}
                  </div>
                ))}
                {genResults.length === 0 && (
                  <div className="text-center py-10 text-slate-200 italic font-bold">اختر عدد الحروف للتوليد</div>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <style>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: transparent;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: #e2e8f0;
          border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: #cbd5e1;
        }
      `}</style>
    </div>
  );
}

function ResultCard({ 
  title, 
  value, 
  onGen, 
  color = 'slate', 
  featured = false 
}: { 
  title: string; 
  value: number; 
  onGen: () => void; 
  color?: 'slate' | 'indigo' | 'sky' | 'emerald';
  featured?: boolean;
}) {
  const colorClasses = {
    slate: {
      text: 'text-slate-800',
      sub: 'text-slate-400',
      btn: 'bg-slate-50 text-slate-400 hover:bg-slate-200 hover:text-slate-600',
      border: 'border-slate-100',
      shadow: 'shadow-slate-100',
      bg: 'bg-slate-50'
    },
    indigo: {
      text: 'text-indigo-700',
      sub: 'text-indigo-400',
      btn: 'bg-indigo-50 text-indigo-600 hover:bg-indigo-600 hover:text-white',
      border: 'border-indigo-100',
      shadow: 'shadow-indigo-100',
      bg: 'bg-indigo-50'
    },
    sky: {
      text: 'text-sky-700',
      sub: 'text-sky-400',
      btn: 'bg-sky-50 text-sky-600 hover:bg-sky-600 hover:text-white',
      border: 'border-sky-100',
      shadow: 'shadow-sky-100',
      bg: 'bg-sky-50'
    },
    emerald: {
      text: 'text-emerald-700',
      sub: 'text-emerald-400',
      btn: 'bg-emerald-50 text-emerald-600 hover:bg-emerald-600 hover:text-white',
      border: 'border-emerald-100',
      shadow: 'shadow-emerald-100',
      bg: 'bg-emerald-50'
    }
  };

  const theme = colorClasses[color] || colorClasses.slate;

  return (
    <div className={`
      relative overflow-hidden p-8 rounded-[2.5rem] transition-all border
      ${featured 
        ? `bg-white shadow-2xl ${theme.shadow} ${theme.border} scale-105 z-10` 
        : `bg-white shadow-sm border-slate-100 hover:shadow-md`
      }
      text-center
    `}>
      <div className={`text-[10px] font-black uppercase tracking-widest mb-2 ${theme.sub}`}>
        {title}
      </div>
      <div className={`text-5xl font-black mb-6 ${theme.text}`}>
        {value}
      </div>
      <button 
        onClick={onGen}
        className={`
          px-5 py-1.5 rounded-full text-[10px] font-black transition-all
          ${theme.btn}
        `}
      >
        توليد
      </button>
      {featured && (
        <div className={`absolute top-0 right-0 w-24 h-24 ${theme.bg} rounded-full -mr-12 -mt-12 opacity-50`} />
      )}
    </div>
  );
}
