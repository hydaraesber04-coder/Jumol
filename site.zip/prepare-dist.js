import fs from 'fs';
import path from 'path';

const distIndexPath = path.resolve('dist', 'index.html');

if (fs.existsSync(distIndexPath)) {
  let content = fs.readFileSync(distIndexPath, 'utf8');

  // تحويل أي inline module script إلى script عادي لتجاوز حظر WebView في الأندرويد
  content = content.replace(/<script\s+type=["']module["']\s+crossorigin>/gi, '<script>');
  content = content.replace(/<script\s+type=["']module["']>/gi, '<script>');

  fs.writeFileSync(distIndexPath, content, 'utf8');
  console.log(' Successfully optimized dist/index.html for Android Cordova (removed type=module constraint).');

  const configPath = path.resolve('config.xml');
  const distConfigPath = path.resolve('dist', 'config.xml');
  if (fs.existsSync(configPath)) {
    fs.copyFileSync(configPath, distConfigPath);
    console.log(' Copied config.xml to dist/');
  }
} else {
  console.warn('⚠️ dist/index.html not found to optimize.');
}
